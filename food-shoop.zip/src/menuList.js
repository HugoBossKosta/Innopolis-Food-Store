export const products = [
  {
    id: 1,
    name:'Устрицы по рокфеллеровски',
    description:'Значимость этих проблем настолько очевидна, что укрепление и развитие структуры',
    price:'2700',
    weight:'/ 500 г',
    img:'images/1.png'
  },
  
]
